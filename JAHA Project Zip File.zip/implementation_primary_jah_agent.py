"""
Primary JAH Agent Implementation
The central CEO agent that coordinates all other agents and makes strategic decisions
"""

import asyncio
from typing import Dict, List, Any, Optional
from dataclasses import dataclass, field
from datetime import datetime, timedelta
import json
import uuid

from .base_agent import (
    BaseAgent, Task, TaskResult, CapabilitySet, ValidationResult, 
    CommunicationMessage, AgentStatus, MessagePriority
)

@dataclass
class AgentRegistry:
    """Registry of all active agents in the system"""
    agents: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    capabilities_map: Dict[str, List[str]] = field(default_factory=dict)
    
    def register_agent(self, agent_id: str, agent_type: str, capabilities: List[str]):
        self.agents[agent_id] = {
            'agent_type': agent_type,
            'capabilities': capabilities,
            'status': 'active',
            'registration_time': datetime.now(),
            'last_seen': datetime.now()
        }
        
        # Update capabilities map
        for capability in capabilities:
            if capability not in self.capabilities_map:
                self.capabilities_map[capability] = []
            self.capabilities_map[capability].append(agent_id)
    
    def get_agents_by_capability(self, capability: str) -> List[str]:
        """Get list of agent IDs that have a specific capability"""
        return self.capabilities_map.get(capability, [])
    
    def get_agent_info(self, agent_id: str) -> Optional[Dict[str, Any]]:
        """Get information about a specific agent"""
        return self.agents.get(agent_id)

@dataclass
class ProjectManagement:
    """Project management and tracking"""
    active_projects: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    project_assignments: Dict[str, List[str]] = field(default_factory=dict)  # project_id -> agent_ids
    
    def create_project(self, project_name: str, description: str, requirements: Dict[str, Any]) -> str:
        project_id = str(uuid.uuid4())
        self.active_projects[project_id] = {
            'name': project_name,
            'description': description,
            'requirements': requirements,
            'status': 'planning',
            'creation_date': datetime.now(),
            'assigned_agents': [],
            'tasks': [],
            'budget': requirements.get('budget', 0),
            'deadline': requirements.get('deadline')
        }
        return project_id
    
    def assign_agent_to_project(self, project_id: str, agent_id: str):
        if project_id in self.active_projects:
            self.active_projects[project_id]['assigned_agents'].append(agent_id)
            if project_id not in self.project_assignments:
                self.project_assignments[project_id] = []
            self.project_assignments[project_id].append(agent_id)

class TaskAnalysisEngine:
    """Analyzes incoming tasks and determines optimal assignment strategies"""
    
    def __init__(self):
        self.complexity_weights = {
            'technical_complexity': 0.3,
            'resource_requirements': 0.25,
            'time_constraints': 0.2,
            'interdependency_level': 0.15,
            'stakeholder_impact': 0.1
        }
    
    def analyze_task_complexity(self, task: Task) -> Dict[str, Any]:
        """Analyze task complexity and requirements"""
        
        complexity_factors = {
            'technical_complexity': self._assess_technical_complexity(task),
            'resource_requirements': self._calculate_resource_needs(task),
            'time_constraints': self._evaluate_timeline_pressure(task),
            'interdependency_level': self._assess_task_dependencies(task),
            'stakeholder_impact': self._evaluate_stakeholder_implications(task)
        }
        
        # Calculate weighted complexity score
        complexity_score = sum(
            factor_score * self.complexity_weights[factor_name]
            for factor_name, factor_score in complexity_factors.items()
        )
        
        return {
            'complexity_score': complexity_score,
            'complexity_factors': complexity_factors,
            'recommended_agent_type': self._determine_optimal_agent_type(task),
            'resource_allocation': self._calculate_resource_allocation(complexity_score),
            'estimated_completion_time': self._estimate_completion_timeline(complexity_factors),
            'risk_assessment': self._assess_execution_risks(complexity_factors)
        }
    
    def _assess_technical_complexity(self, task: Task) -> float:
        """Assess technical complexity (0.0 to 1.0)"""
        complexity_indicators = task.requirements.get('technical_requirements', {})
        
        score = 0.0
        if complexity_indicators.get('requires_programming'):
            score += 0.3
        if complexity_indicators.get('requires_api_integration'):
            score += 0.2
        if complexity_indicators.get('requires_database_work'):
            score += 0.2
        if complexity_indicators.get('requires_machine_learning'):
            score += 0.3
        
        return min(score, 1.0)
    
    def _calculate_resource_needs(self, task: Task) -> float:
        """Calculate resource requirements intensity (0.0 to 1.0)"""
        estimated_hours = task.estimated_hours or 2.0
        
        # Normalize based on typical task ranges
        if estimated_hours <= 1:
            return 0.2
        elif estimated_hours <= 4:
            return 0.4
        elif estimated_hours <= 8:
            return 0.6
        elif estimated_hours <= 16:
            return 0.8
        else:
            return 1.0
    
    def _evaluate_timeline_pressure(self, task: Task) -> float:
        """Evaluate timeline pressure (0.0 to 1.0)"""
        if not task.deadline:
            return 0.3  # Normal pressure
        
        time_until_deadline = (task.deadline - datetime.now()).total_seconds() / 3600  # hours
        estimated_hours = task.estimated_hours or 2.0
        
        pressure_ratio = estimated_hours / time_until_deadline
        
        if pressure_ratio <= 0.25:
            return 0.2  # Low pressure
        elif pressure_ratio <= 0.5:
            return 0.4  # Normal pressure
        elif pressure_ratio <= 0.75:
            return 0.6  # Moderate pressure
        elif pressure_ratio <= 1.0:
            return 0.8  # High pressure
        else:
            return 1.0  # Critical pressure
    
    def _assess_task_dependencies(self, task: Task) -> float:
        """Assess task interdependency level (0.0 to 1.0)"""
        dependencies = task.requirements.get('dependencies', [])
        return min(len(dependencies) * 0.2, 1.0)
    
    def _evaluate_stakeholder_implications(self, task: Task) -> float:
        """Evaluate stakeholder impact (0.0 to 1.0)"""
        impact_level = task.requirements.get('stakeholder_impact', 'medium')
        
        impact_scores = {
            'low': 0.2,
            'medium': 0.5,
            'high': 0.8,
            'critical': 1.0
        }
        
        return impact_scores.get(impact_level, 0.5)
    
    def _determine_optimal_agent_type(self, task: Task) -> str:
        """Determine the most suitable agent type for the task"""
        task_type_mapping = {
            'content_creation': 'MarketingAgent',
            'market_research': 'ResearchAgent',
            'software_development': 'TechnicalAgent',
            'system_integration': 'TechnicalAgent',
            'lead_qualification': 'SalesAgent',
            'proposal_development': 'SalesAgent',
            'customer_inquiry': 'CustomerServiceAgent',
            'financial_analysis': 'FinancialAgent',
            'data_analysis': 'ResearchAgent'
        }
        
        return task_type_mapping.get(task.task_type, 'TechnicalAgent')
    
    def _calculate_resource_allocation(self, complexity_score: float) -> Dict[str, Any]:
        """Calculate recommended resource allocation"""
        base_priority = 50
        priority_adjustment = int(complexity_score * 50)
        
        return {
            'recommended_priority': base_priority + priority_adjustment,
            'resource_intensity': complexity_score,
            'monitoring_level': 'high' if complexity_score > 0.7 else 'normal'
        }
    
    def _estimate_completion_timeline(self, complexity_factors: Dict[str, float]) -> Dict[str, Any]:
        """Estimate completion timeline based on complexity factors"""
        base_hours = 2.0
        
        # Adjust based on complexity factors
        multiplier = 1.0 + sum(complexity_factors.values()) / 2
        estimated_hours = base_hours * multiplier
        
        return {
            'estimated_hours': estimated_hours,
            'confidence_level': max(0.5, 1.0 - sum(complexity_factors.values()) / 5),
            'buffer_recommendation': estimated_hours * 0.2  # 20% buffer
        }
    
    def _assess_execution_risks(self, complexity_factors: Dict[str, float]) -> Dict[str, Any]:
        """Assess execution risks"""
        risk_level = sum(complexity_factors.values()) / len(complexity_factors)
        
        risk_categories = {
            'technical_risk': complexity_factors['technical_complexity'],
            'timeline_risk': complexity_factors['time_constraints'],
            'resource_risk': complexity_factors['resource_requirements'],
            'coordination_risk': complexity_factors['interdependency_level']
        }
        
        return {
            'overall_risk_level': risk_level,
            'risk_categories': risk_categories,
            'mitigation_required': risk_level > 0.7,
            'recommended_checkpoints': max(1, int(risk_level * 5))
        }

class SubAgentFactory:
    """Factory for creating and managing sub-agents"""
    
    def __init__(self):
        self.agent_templates = {
            'MarketingAgent': {
                'capabilities': ['content_creation', 'campaign_management', 'social_media_automation'],
                'resource_requirements': {'memory': '1GB', 'cpu': '1 core'},
                'initialization_time': 30
            },
            'SalesAgent': {
                'capabilities': ['lead_qualification', 'proposal_development', 'client_relationship_management'],
                'resource_requirements': {'memory': '512MB', 'cpu': '0.5 core'},
                'initialization_time': 20
            },
            'TechnicalAgent': {
                'capabilities': ['software_development', 'system_integration', 'troubleshooting'],
                'resource_requirements': {'memory': '2GB', 'cpu': '2 cores'},
                'initialization_time': 45
            },
            'ResearchAgent': {
                'capabilities': ['market_research', 'data_analysis', 'report_generation'],
                'resource_requirements': {'memory': '1GB', 'cpu': '1 core'},
                'initialization_time': 25
            },
            'CustomerServiceAgent': {
                'capabilities': ['customer_inquiry_handling', 'issue_resolution', 'satisfaction_tracking'],
                'resource_requirements': {'memory': '512MB', 'cpu': '0.5 core'},
                'initialization_time': 15
            }
        }
    
    async def create_specialized_agent(self, agent_type: str, task_requirements: Dict[str, Any]) -> Dict[str, Any]:
        """Create a new specialized agent instance"""
        
        if agent_type not in self.agent_templates:
            raise ValueError(f"Unknown agent type: {agent_type}")
        
        template = self.agent_templates[agent_type]
        agent_id = f"{agent_type.lower()}_{uuid.uuid4().hex[:8]}"
        
        # Configure agent based on task requirements
        agent_config = {
            'agent_id': agent_id,
            'agent_type': agent_type,
            'capabilities': template['capabilities'],
            'resource_allocation': template['resource_requirements'],
            'task_specialization': task_requirements.get('specialization'),
            'performance_targets': task_requirements.get('performance_targets', {}),
            'quality_standards': task_requirements.get('quality_standards', {})
        }
        
        # Simulate agent creation (in real implementation, this would instantiate the actual agent)
        creation_result = {
            'agent_id': agent_id,
            'agent_type': agent_type,
            'status': 'created',
            'configuration': agent_config,
            'creation_time': datetime.now(),
            'initialization_time': template['initialization_time']
        }
        
        return creation_result

class PrimaryJAHAgent(BaseAgent):
    """Primary JAH Agent - Central coordination and strategic management"""
    
    def __init__(self, agent_config: Dict[str, Any]):
        super().__init__("primary_jah_agent", agent_config)
        
        # Core components
        self.task_analysis_engine = TaskAnalysisEngine()
        self.sub_agent_factory = SubAgentFactory()
        self.agent_registry = AgentRegistry()
        self.project_management = ProjectManagement()
        
        # Strategic management components
        self.resource_optimizer = ResourceOptimizer()
        self.performance_monitor = PerformanceMonitor()
        self.decision_engine = StrategicDecisionEngine()
        
        # Communication and coordination
        self.coordination_manager = CoordinationManager()
        self.workflow_orchestrator = WorkflowOrchestrator()
        
        # Initialize system state
        self.system_state = {
            'total_agents': 1,  # Starting with just the primary agent
            'active_tasks': 0,
            'completed_tasks': 0,
            'system_health': 'healthy',
            'last_optimization': datetime.now()
        }
    
    def initialize_capabilities(self) -> CapabilitySet:
        """Initialize Primary JAH Agent capabilities"""
        return CapabilitySet([
            'strategic_planning',
            'task_analysis',
            'agent_coordination', 
            'resource_optimization',
            'decision_making',
            'workflow_orchestration',
            'performance_monitoring',
            'stakeholder_communication',
            'system_optimization',
            'project_management'
        ])
    
    async def process_task(self, task: Task) -> TaskResult:
        """Process tasks that require CEO-level attention"""
        
        try:
            self.logger.info(f"Primary JAH Agent processing task: {task.title}")
            
            if task.task_type == 'strategic_planning':
                return await self._handle_strategic_planning_task(task)
            elif task.task_type == 'agent_coordination':
                return await self._handle_agent_coordination_task(task)
            elif task.task_type == 'system_optimization':
                return await self._handle_system_optimization_task(task)
            elif task.task_type == 'stakeholder_communication':
                return await self._handle_stakeholder_communication_task(task)
            elif task.task_type == 'task_delegation':
                return await self._handle_task_delegation(task)
            else:
                # For other task types, analyze and delegate to appropriate agent
                return await self._delegate_task_to_specialist(task)
                
        except Exception as e:
            self.logger.error(f"Error processing task {task.task_id}: {str(e)}")
            return TaskResult(
                task_id=task.task_id,
                status='failed',
                error_message=str(e)
            )
    
    def validate_task_compatibility(self, task: Task) -> ValidationResult:
        """Validate task compatibility with Primary JAH Agent"""
        
        # Primary agent can handle strategic tasks or delegate others
        strategic_tasks = [
            'strategic_planning', 'agent_coordination', 'system_optimization',
            'stakeholder_communication', 'task_delegation'
        ]
        
        if task.task_type in strategic_tasks:
            return ValidationResult(
                is_valid=True,
                confidence_level=0.95
            )
        
        # Can also handle delegation of any task type
        return ValidationResult(
            is_valid=True,
            confidence_level=0.8,
            alternatives=['delegate_to_specialist']
        )
    
    async def _handle_strategic_planning_task(self, task: Task) -> TaskResult:
        """Handle strategic planning tasks"""
        
        planning_requirements = task.requirements.get('planning_scope', {})
        
        # Analyze current system state
        system_analysis = await self._analyze_system_performance()
        
        # Generate strategic recommendations
        strategic_plan = {
            'system_analysis': system_analysis,
            'optimization_opportunities': await self._identify_optimization_opportunities(),
            'resource_allocation_recommendations': await self._optimize_resource_allocation(),
            'performance_targets': self._set_performance_targets(),
            'implementation_timeline': self._create_implementation_timeline()
        }
        
        return TaskResult(
            task_id=task.task_id,
            status='completed',
            deliverables={'strategic_plan': strategic_plan},
            quality_metrics={'completeness': 0.95, 'strategic_value': 0.9}
        )
    
    async def _handle_task_delegation(self, task: Task) -> TaskResult:
        """Handle task delegation to appropriate specialist agents"""
        
        # Analyze the task that needs to be delegated
        original_task_info = task.requirements.get('original_task')
        if not original_task_info:
            raise ValueError("No original task information provided for delegation")
        
        # Create Task object from the information
        delegated_task = Task(
            task_id=original_task_info['task_id'],
            title=original_task_info['title'],
            description=original_task_info['description'],
            task_type=original_task_info['task_type'],
            complexity_level=original_task_info.get('complexity_level', 'medium'),
            priority_score=original_task_info.get('priority_score', 50),
            requirements=original_task_info.get('requirements', {}),
            estimated_hours=original_task_info.get('estimated_hours'),
            deadline=datetime.fromisoformat(original_task_info['deadline']) if original_task_info.get('deadline') else None
        )
        
        # Analyze task and determine optimal assignment
        task_analysis = self.task_analysis_engine.analyze_task_complexity(delegated_task)
        
        # Find or create appropriate agent
        optimal_agent_type = task_analysis['recommended_agent_type']
        suitable_agents = self.agent_registry.get_agents_by_capability(
            delegated_task.task_type
        )
        
        assigned_agent_id = None
        
        if suitable_agents:
            # Select best available agent
            assigned_agent_id = await self._select_optimal_agent(suitable_agents, task_analysis)
        else:
            # Create new specialized agent
            agent_creation_result = await self.sub_agent_factory.create_specialized_agent(
                optimal_agent_type, 
                delegated_task.requirements
            )
            assigned_agent_id = agent_creation_result['agent_id']
            
            # Register the new agent
            self.agent_registry.register_agent(
                agent_creation_result['agent_id'],
                agent_creation_result['agent_type'],
                agent_creation_result['configuration']['capabilities']
            )
        
        # Assign task to selected agent
        assignment_result = await self._assign_task_to_agent(delegated_task, assigned_agent_id)
        
        return TaskResult(
            task_id=task.task_id,
            status='completed',
            deliverables={
                'assignment_result': assignment_result,
                'assigned_agent_id': assigned_agent_id,
                'task_analysis': task_analysis
            },
            quality_metrics={'assignment_confidence': task_analysis.get('confidence_level', 0.8)}
        )
    
    async def _delegate_task_to_specialist(self, task: Task) -> TaskResult:
        """Delegate task to appropriate specialist agent"""
        
        # This creates a delegation task
        delegation_task = Task(
            task_id=f"delegation_{task.task_id}",
            title=f"Delegate: {task.title}",
            description=f"Delegate task {task.task_id} to appropriate specialist",
            task_type='task_delegation',
            complexity_level='medium',
            priority_score=task.priority_score,
            requirements={
                'original_task': {
                    'task_id': task.task_id,
                    'title': task.title,
                    'description': task.description,
                    'task_type': task.task_type,
                    'complexity_level': task.complexity_level,
                    'priority_score': task.priority_score,
                    'requirements': task.requirements,
                    'estimated_hours': task.estimated_hours,
                    'deadline': task.deadline.isoformat() if task.deadline else None,
                    'assigning_agent_id': task.assigning_agent_id
                }
            }
        )
        
        return await self._handle_task_delegation(delegation_task)
    
    async def _select_optimal_agent(self, candidate_agents: List[str], task_analysis: Dict[str, Any]) -> str:
        """Select the most suitable agent from available candidates"""
        
        # For now, simple selection based on availability
        # In full implementation, this would consider:
        # - Current workload
        # - Performance history
        # - Capability match score
        # - Resource utilization
        
        for agent_id in candidate_agents:
            agent_info = self.agent_registry.get_agent_info(agent_id)
            if agent_info and agent_info['status'] == 'active':
                return agent_id
        
        # Fallback to first available agent
        return candidate_agents[0] if candidate_agents else None
    
    async def _assign_task_to_agent(self, task: Task, agent_id: str) -> Dict[str, Any]:
        """Assign task to specific agent"""
        
        # Set the assigning agent
        task.assigning_agent_id = self.agent_id
        
        # Send task assignment message
        assignment_message = CommunicationMessage(
            message_id=str(uuid.uuid4()),
            sender_id=self.agent_id,
            recipient_id=agent_id,
            message_type="task_assignment",
            content={
                'task': task.__dict__,
                'assignment_time': datetime.now().isoformat(),
                'priority': 'normal'
            },
            priority=MessagePriority.HIGH
        )
        
        # Send the assignment
        success = await self.communication_handler.send_message(assignment_message)
        
        if success:
            # Update system state
            self.system_state['active_tasks'] += 1
            
            return {
                'status': 'assigned',
                'agent_id': agent_id,
                'assignment_time': datetime.now().isoformat(),
                'task_id': task.task_id
            }
        else:
            raise Exception(f"Failed to assign task {task.task_id} to agent {agent_id}")
    
    async def _analyze_system_performance(self) -> Dict[str, Any]:
        """Analyze overall system performance"""
        
        return {
            'system_health': self.system_state['system_health'],
            'total_agents': self.system_state['total_agents'],
            'active_tasks': self.system_state['active_tasks'],
            'completed_tasks': self.system_state['completed_tasks'],
            'performance_metrics': self.performance_metrics.__dict__,
            'resource_utilization': self.resource_manager.get_utilization_metrics(),
            'last_analysis': datetime.now().isoformat()
        }
    
    async def _identify_optimization_opportunities(self) -> List[Dict[str, Any]]:
        """Identify system optimization opportunities"""
        
        opportunities = []
        
        # Check agent utilization
        if self.system_state['active_tasks'] > self.system_state['total_agents'] * 2:
            opportunities.append({
                'type': 'capacity_expansion',
                'description': 'High task-to-agent ratio suggests need for additional agents',
                'priority': 'high',
                'expected_impact': 'Improved task processing speed'
            })
        
        # Check error rates
        if self.performance_metrics.error_rate > 0.1:
            opportunities.append({
                'type': 'quality_improvement',
                'description': 'High error rate indicates need for process optimization',
                'priority': 'medium',
                'expected_impact': 'Reduced rework and improved quality'
            })
        
        return opportunities
    
    async def _optimize_resource_allocation(self) -> Dict[str, Any]:
        """Optimize resource allocation across agents"""
        
        return {
            'current_allocation': 'balanced',
            'recommended_changes': [],
            'efficiency_score': 0.85,
            'optimization_timestamp': datetime.now().isoformat()
        }
    
    def _set_performance_targets(self) -> Dict[str, Any]:
        """Set performance targets for the system"""
        
        return {
            'task_completion_rate': 0.95,
            'average_quality_score': 0.85,
            'response_time_target': 2.0,  # hours
            'resource_utilization_target': 0.80,
            'error_rate_target': 0.05
        }
    
    def _create_implementation_timeline(self) -> Dict[str, Any]:
        """Create implementation timeline for strategic initiatives"""
        
        return {
            'phase_1': {
                'duration': '30 days',
                'objectives': ['System stabilization', 'Performance baseline'],
                'deliverables': ['Performance report', 'Optimization plan']
            },
            'phase_2': {
                'duration': '60 days', 
                'objectives': ['Capacity expansion', 'Process optimization'],
                'deliverables': ['Additional agents', 'Improved workflows']
            },
            'phase_3': {
                'duration': '90 days',
                'objectives': ['Advanced capabilities', 'Strategic positioning'],
                'deliverables': ['Enhanced features', 'Market expansion']
            }
        }

# Placeholder classes for components that would be implemented in separate modules
class ResourceOptimizer:
    def __init__(self):
        pass

class PerformanceMonitor:
    def __init__(self):
        pass

class StrategicDecisionEngine:
    def __init__(self):
        pass

class CoordinationManager:
    def __init__(self):
        pass

class WorkflowOrchestrator:
    def __init__(self):
        pass