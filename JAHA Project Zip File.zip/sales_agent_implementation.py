"""
Sales Agent Implementation
Specialized agent for lead qualification, proposal development, and client relationship management
"""

import asyncio
from typing import Dict, List, Any, Optional
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
import json
import uuid

from ..core.base_agent import BaseAgent, Task, TaskResult, CapabilitySet, ValidationResult

class LeadStatus(Enum):
    NEW = "new"
    CONTACTED = "contacted"
    QUALIFIED = "qualified"
    PROPOSAL_SENT = "proposal_sent"
    NEGOTIATING = "negotiating"
    CLOSED_WON = "closed_won"
    CLOSED_LOST = "closed_lost"
    NURTURING = "nurturing"

class DealStage(Enum):
    PROSPECTING = "prospecting"
    DISCOVERY = "discovery"
    PROPOSAL = "proposal"
    NEGOTIATION = "negotiation"
    CLOSING = "closing"
    POST_SALE = "post_sale"

@dataclass
class Lead:
    lead_id: str
    contact_name: str
    company_name: str
    email: str
    phone: Optional[str] = None
    job_title: Optional[str] = None
    company_size: Optional[str] = None
    industry: Optional[str] = None
    lead_source: Optional[str] = None
    status: LeadStatus = LeadStatus.NEW
    score: float = 0.0
    qualification_notes: str = ""
    created_date: datetime = field(default_factory=datetime.now)
    last_contact_date: Optional[datetime] = None
    expected_value: float = 0.0
    probability: float = 0.0

@dataclass
class SalesOpportunity:
    opportunity_id: str
    lead: Lead
    deal_stage: DealStage
    opportunity_value: float
    probability: float
    expected_close_date: datetime
    products_services: List[str]
    competition: List[str] = field(default_factory=list)
    decision_makers: List[Dict[str, str]] = field(default_factory=list)
    next_steps: List[str] = field(default_factory=list)
    notes: str = ""

@dataclass
class Proposal:
    proposal_id: str
    opportunity_id: str
    client_name: str
    proposal_title: str
    executive_summary: str
    solution_description: str
    pricing: Dict[str, Any]
    timeline: Dict[str, datetime]
    terms_conditions: str
    validity_period: datetime
    status: str = "draft"
    created_date: datetime = field(default_factory=datetime.now)

class LeadQualificationEngine:
    """Qualify and score leads based on multiple criteria"""
    
    def __init__(self):
        self.scoring_criteria = {
            'company_size': {
                'enterprise': 25,
                'large': 20,
                'medium': 15,
                'small': 10,
                'startup': 5
            },
            'industry_fit': {
                'high': 20,
                'medium': 15,
                'low': 5,
                'none': 0
            },
            'budget_authority': {
                'decision_maker': 20,
                'influencer': 15,
                'user': 10,
                'unknown': 5
            },
            'timeline': {
                'immediate': 20,
                'short_term': 15,
                'medium_term': 10,
                'long_term': 5,
                'unknown': 3
            },
            'engagement_level': {
                'high': 15,
                'medium': 10,
                'low': 5,
                'none': 0
            }
        }
        
        self.qualification_questions = [
            "What is your current solution for this challenge?",
            "What is your timeline for implementing a new solution?",
            "Who else is involved in the decision-making process?",
            "What is your budget range for this project?",
            "What are your key success criteria?",
            "What challenges are you facing with your current approach?",
            "How urgent is solving this problem for your organization?"
        ]
    
    async def qualify_lead(self, lead: Lead, qualification_data: Dict[str, Any]) -> Dict[str, Any]:
        """Qualify lead and calculate qualification score"""
        
        # Calculate lead score based on criteria
        score_breakdown = {}
        total_score = 0
        
        # Company size scoring
        company_size_score = self.scoring_criteria['company_size'].get(
            qualification_data.get('company_size', 'unknown'), 5
        )
        score_breakdown['company_size'] = company_size_score
        total_score += company_size_score
        
        # Industry fit scoring
        industry_fit_score = self.scoring_criteria['industry_fit'].get(
            qualification_data.get('industry_fit', 'unknown'), 5
        )
        score_breakdown['industry_fit'] = industry_fit_score
        total_score += industry_fit_score
        
        # Budget authority scoring
        budget_authority_score = self.scoring_criteria['budget_authority'].get(
            qualification_data.get('budget_authority', 'unknown'), 5
        )
        score_breakdown['budget_authority'] = budget_authority_score
        total_score += budget_authority_score
        
        # Timeline scoring
        timeline_score = self.scoring_criteria['timeline'].get(
            qualification_data.get('timeline', 'unknown'), 3
        )
        score_breakdown['timeline'] = timeline_score
        total_score += timeline_score
        
        # Engagement level scoring
        engagement_score = self.scoring_criteria['engagement_level'].get(
            qualification_data.get('engagement_level', 'unknown'), 0
        )
        score_breakdown['engagement_level'] = engagement_score
        total_score += engagement_score
        
        # Calculate final qualification score (0-100)
        qualification_score = min(total_score, 100)
        
        # Determine qualification status
        if qualification_score >= 70:
            qualification_status = "highly_qualified"
            priority = "high"
        elif qualification_score >= 50:
            qualification_status = "qualified" 
            priority = "medium"
        elif qualification_score >= 30:
            qualification_status = "partially_qualified"
            priority = "low"
        else:
            qualification_status = "unqualified"
            priority = "very_low"
        
        # Generate qualification insights
        insights = await self._generate_qualification_insights(qualification_data, score_breakdown)
        
        # Determine next steps
        next_steps = await self._determine_next_steps(qualification_status, qualification_data)
        
        return {
            'qualification_score': qualification_score,
            'qualification_status': qualification_status,
            'priority': priority,
            'score_breakdown': score_breakdown,
            'insights': insights,
            'next_steps': next_steps,
            'recommended_actions': await self._generate_recommended_actions(qualification_status, qualification_data)
        }
    
    async def _generate_qualification_insights(self, qualification_data: Dict[str, Any], 
                                            score_breakdown: Dict[str, float]) -> List[str]:
        """Generate insights based on qualification data"""
        insights = []
        
        if score_breakdown.get('company_size', 0) >= 20:
            insights.append("Strong fit - target company size aligns with our ideal customer profile")
        
        if score_breakdown.get('industry_fit', 0) >= 15:
            insights.append("Excellent industry fit - high likelihood of success")
        elif score_breakdown.get('industry_fit', 0) <= 5:
            insights.append("Industry fit concerns - may require customized approach")
        
        if score_breakdown.get('budget_authority', 0) >= 15:
            insights.append("Good budget authority - contact has decision-making power")
        elif score_breakdown.get('budget_authority', 0) <= 10:
            insights.append("Need to identify key decision makers")
        
        if score_breakdown.get('timeline', 0) >= 15:
            insights.append("Urgent timeline - opportunity for quick close")
        elif score_breakdown.get('timeline', 0) <= 5:
            insights.append("Long sales cycle expected - focus on relationship building")
        
        return insights
    
    async def _determine_next_steps(self, qualification_status: str, qualification_data: Dict[str, Any]) -> List[str]:
        """Determine next steps based on qualification status"""
        
        next_steps_map = {
            "highly_qualified": [
                "Schedule discovery call within 48 hours",
                "Prepare detailed solution presentation",
                "Research company's specific challenges",
                "Identify additional stakeholders"
            ],
            "qualified": [
                "Schedule qualification call",
                "Send relevant case studies",
                "Gather more detailed requirements",
                "Identify budget and timeline"
            ],
            "partially_qualified": [
                "Nurture with valuable content",
                "Schedule educational session",
                "Gather missing qualification information",
                "Build relationship with key contacts"
            ],
            "unqualified": [
                "Add to nurture campaign",
                "Provide educational resources",
                "Schedule follow-up in 3-6 months",
                "Focus on building awareness"
            ]
        }
        
        return next_steps_map.get(qualification_status, ["Review and assess lead"])
    
    async def _generate_recommended_actions(self, qualification_status: str, 
                                          qualification_data: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Generate specific recommended actions with priorities and timelines"""
        
        actions = []
        
        if qualification_status in ["highly_qualified", "qualified"]:
            actions.extend([
                {
                    "action": "Schedule discovery call",
                    "priority": "high",
                    "timeline": "24-48 hours",
                    "owner": "sales_rep",
                    "description": "Deep dive into requirements and challenges"
                },
                {
                    "action": "Research prospect company",
                    "priority": "high",
                    "timeline": "Before call",
                    "owner": "sales_rep",
                    "description": "Industry trends, company news, competitive landscape"
                }
            ])
        
        if qualification_data.get('budget_authority') == 'unknown':
            actions.append({
                "action": "Identify decision makers",
                "priority": "medium",
                "timeline": "Within 1 week",
                "owner": "sales_rep",
                "description": "Map out decision-making process and key stakeholders"
            })
        
        return actions

class ProposalGenerator:
    """Generate customized proposals based on opportunity details"""
    
    def __init__(self):
        self.proposal_templates = {
            'consulting': {
                'sections': ['executive_summary', 'situation_analysis', 'recommended_solution', 
                           'implementation_plan', 'investment', 'next_steps'],
                'default_terms': 'Net 30 payment terms, 50% upfront for projects over $10k'
            },
            'software': {
                'sections': ['executive_summary', 'technical_requirements', 'solution_architecture',
                           'implementation_timeline', 'pricing', 'support_maintenance'],
                'default_terms': 'Monthly subscription with annual discounts available'
            },
            'service': {
                'sections': ['executive_summary', 'service_overview', 'deliverables',
                           'timeline', 'investment', 'guarantee'],
                'default_terms': 'Net 15 payment terms, satisfaction guarantee'
            }
        }
    
    async def generate_proposal(self, opportunity: SalesOpportunity, 
                              proposal_requirements: Dict[str, Any]) -> Proposal:
        """Generate comprehensive proposal for sales opportunity"""
        
        proposal_type = proposal_requirements.get('proposal_type', 'consulting')
        template = self.proposal_templates.get(proposal_type, self.proposal_templates['consulting'])
        
        # Generate executive summary
        executive_summary = await self._generate_executive_summary(opportunity, proposal_requirements)
        
        # Generate solution description
        solution_description = await self._generate_solution_description(opportunity, proposal_requirements)
        
        # Generate pricing structure
        pricing = await self._generate_pricing_structure(opportunity, proposal_requirements)
        
        # Generate timeline
        timeline = await self._generate_project_timeline(opportunity, proposal_requirements)
        
        # Generate terms and conditions
        terms_conditions = await self._generate_terms_conditions(proposal_type, proposal_requirements)
        
        # Set validity period (default 30 days)
        validity_period = datetime.now() + timedelta(days=proposal_requirements.get('validity_days', 30))
        
        proposal = Proposal(
            proposal_id=f"PROP_{datetime.now().strftime('%Y%m%d')}_{uuid.uuid4().hex[:6]}",
            opportunity_id=opportunity.opportunity_id,
            client_name=opportunity.lead.company_name,
            proposal_title=f"Proposal for {opportunity.lead.company_name}",
            executive_summary=executive_summary,
            solution_description=solution_description,
            pricing=pricing,
            timeline=timeline,
            terms_conditions=terms_conditions,
            validity_period=validity_period
        )
        
        return proposal
    
    async def _generate_executive_summary(self, opportunity: SalesOpportunity, 
                                        requirements: Dict[str, Any]) -> str:
        """Generate executive summary for proposal"""
        
        return f"""
        Dear {opportunity.lead.contact_name},

        Thank you for the opportunity to present our solution for {opportunity.lead.company_name}. 
        Based on our discussions, we understand your key challenges include {', '.join(requirements.get('challenges', ['operational efficiency', 'cost optimization']))}.

        Our proposed solution will deliver:
        • {requirements.get('key_benefit_1', 'Improved operational efficiency')}
        • {requirements.get('key_benefit_2', 'Cost reduction of 15-25%')}
        • {requirements.get('key_benefit_3', 'Enhanced competitive positioning')}

        We are confident this solution will provide significant value to {opportunity.lead.company_name} 
        and look forward to partnering with you to achieve your business objectives.

        Investment: ${opportunity.opportunity_value:,.2f}
        Timeline: {requirements.get('project_duration', '3-4 months')}
        Expected ROI: {requirements.get('expected_roi', '300%')} within the first year
        """
    
    async def _generate_solution_description(self, opportunity: SalesOpportunity, 
                                           requirements: Dict[str, Any]) -> str:
        """Generate detailed solution description"""
        
        services = requirements.get('services', ['Strategic Consulting', 'Implementation Support'])
        
        solution_desc = f"""
        Our comprehensive solution for {opportunity.lead.company_name} includes:

        """
        
        for i, service in enumerate(services, 1):
            solution_desc += f"""
        {i}. {service}
           • Detailed analysis and recommendations
           • Best practices implementation
           • Ongoing support and optimization
        """
        
        solution_desc += f"""
        
        Key Deliverables:
        • {requirements.get('deliverable_1', 'Comprehensive analysis report')}
        • {requirements.get('deliverable_2', 'Implementation roadmap')}
        • {requirements.get('deliverable_3', 'Training and knowledge transfer')}
        • {requirements.get('deliverable_4', '3 months of post-implementation support')}

        Success Metrics:
        • {requirements.get('success_metric_1', 'Efficiency improvement of 20%+')}
        • {requirements.get('success_metric_2', 'Cost reduction of $50k+ annually')}
        • {requirements.get('success_metric_3', 'ROI achievement within 12 months')}
        """
        
        return solution_desc
    
    async def _generate_pricing_structure(self, opportunity: SalesOpportunity, 
                                        requirements: Dict[str, Any]) -> Dict[str, Any]:
        """Generate pricing structure for proposal"""
        
        pricing_model = requirements.get('pricing_model', 'fixed_fee')
        
        if pricing_model == 'fixed_fee':
            return {
                'model': 'Fixed Fee',
                'total_investment': opportunity.opportunity_value,
                'payment_schedule': {
                    'phase_1': opportunity.opportunity_value * 0.4,
                    'phase_2': opportunity.opportunity_value * 0.3,
                    'phase_3': opportunity.opportunity_value * 0.3
                },
                'included_services': requirements.get('included_services', [
                    'All consulting services',
                    'Implementation support', 
                    'Training materials',
                    '90 days post-implementation support'
                ]),
                'optional_services': requirements.get('optional_services', [
                    'Extended support (12 months): $5,000',
                    'Additional training sessions: $2,500 each',
                    'Custom integrations: $150/hour'
                ])
            }
        elif pricing_model == 'time_materials':
            return {
                'model': 'Time & Materials',
                'hourly_rates': {
                    'senior_consultant': 200,
                    'consultant': 150,
                    'analyst': 100
                },
                'estimated_hours': requirements.get('estimated_hours', 400),
                'estimated_total': requirements.get('estimated_hours', 400) * 150,
                'not_to_exceed': opportunity.opportunity_value
            }
        else:
            return {
                'model': 'Value-Based',
                'investment': opportunity.opportunity_value,
                'value_delivered': opportunity.opportunity_value * 3,
                'roi_guarantee': 'Minimum 200% ROI or money back'
            }
    
    async def _generate_project_timeline(self, opportunity: SalesOpportunity, 
                                       requirements: Dict[str, Any]) -> Dict[str, datetime]:
        """Generate project timeline"""
        
        start_date = requirements.get('project_start_date', datetime.now() + timedelta(days=14))
        duration_weeks = requirements.get('duration_weeks', 12)
        
        timeline = {
            'project_start': start_date,
            'project_end': start_date + timedelta(weeks=duration_weeks),
            'phase_1_end': start_date + timedelta(weeks=duration_weeks * 0.3),
            'phase_2_end': start_date + timedelta(weeks=duration_weeks * 0.7),
            'go_live': start_date + timedelta(weeks=duration_weeks * 0.9),
            'project_closure': start_date + timedelta(weeks=duration_weeks)
        }
        
        return timeline
    
    async def _generate_terms_conditions(self, proposal_type: str, 
                                       requirements: Dict[str, Any]) -> str:
        """Generate terms and conditions"""
        
        default_terms = self.proposal_templates[proposal_type]['default_terms']
        custom_terms = requirements.get('custom_terms', [])
        
        terms = f"""
        Standard Terms and Conditions:
        • {default_terms}
        • All work will be performed in accordance with industry best practices
        • Client will provide necessary access and resources for project success
        • Changes to scope require written approval and may affect timeline/investment
        
        """
        
        if custom_terms:
            terms += "Additional Terms:\n"
            for term in custom_terms:
                terms += f"• {term}\n"
        
        return terms

class ClientRelationshipManager:
    """Manage client relationships and communication"""
    
    def __init__(self):
        self.communication_templates = {
            'initial_contact': {
                'subject': 'Following up on your inquiry',
                'template': 'Thank you for your interest in our services...'
            },
            'qualification_follow_up': {
                'subject': 'Next steps for {company_name}',
                'template': 'Based on our conversation, I wanted to outline...'
            },
            'proposal_submission': {
                'subject': 'Proposal for {company_name} - {proposal_title}',
                'template': 'Attached is our comprehensive proposal...'
            },
            'follow_up_proposal': {
                'subject': 'Following up on our proposal',
                'template': 'I wanted to follow up on the proposal we submitted...'
            }
        }
    
    async def generate_communication(self, communication_type: str, 
                                   context: Dict[str, Any]) -> Dict[str, str]:
        """Generate personalized communication based on type and context"""
        
        template = self.communication_templates.get(communication_type)
        if not template:
            return {'subject': 'Follow up', 'content': 'Following up on our previous conversation.'}
        
        # Personalize subject line
        subject = template['subject'].format(**context)
        
        # Generate content based on type
        if communication_type == 'initial_contact':
            content = await self._generate_initial_contact_email(context)
        elif communication_type == 'qualification_follow_up':
            content = await self._generate_qualification_follow_up(context)
        elif communication_type == 'proposal_submission':
            content = await self._generate_proposal_submission_email(context)
        elif communication_type == 'follow_up_proposal':
            content = await self._generate_proposal_follow_up(context)
        else:
            content = template['template']
        
        return {
            'subject': subject,
            'content': content,
            'recommended_send_time': await self._calculate_optimal_send_time(context),
            'follow_up_date': await self._calculate_follow_up_date(communication_type)
        }
    
    async def _generate_initial_contact_email(self, context: Dict[str, Any]) -> str:
        """Generate initial contact email"""
        
        return f"""
        Hi {context.get('contact_name', 'there')},

        Thank you for your interest in our {context.get('service_type', 'consulting services')}. 
        I understand you're looking to {context.get('primary_goal', 'improve operational efficiency')}.

        Based on similar projects with companies like {context.get('company_name', 'yours')}, 
        we've typically helped organizations achieve:
        • 20-30% improvement in operational efficiency
        • Significant cost reductions within the first year
        • Enhanced competitive positioning in the market

        I'd love to learn more about your specific challenges and goals. 
        Would you be available for a brief 15-minute call this week?

        Best regards,
        Sales Team
        """
    
    async def _generate_qualification_follow_up(self, context: Dict[str, Any]) -> str:
        """Generate qualification follow-up email"""
        
        return f"""
        Hi {context.get('contact_name')},

        Thank you for taking the time to speak with me yesterday about {context.get('discussion_topic', 'your business challenges')}.

        Based on our conversation, I understand your key priorities are:
        • {context.get('priority_1', 'Improving operational efficiency')}
        • {context.get('priority_2', 'Reducing costs')}
        • {context.get('priority_3', 'Enhancing customer experience')}

        Next steps:
        1. I'll prepare a customized proposal based on your requirements
        2. I'll include relevant case studies from similar organizations
        3. We'll schedule a presentation for your team next week

        I'll have the proposal ready by {context.get('proposal_delivery_date', 'Friday')}.

        Please let me know if you have any questions in the meantime.

        Best regards,
        Sales Team
        """
    
    async def _generate_proposal_submission_email(self, context: Dict[str, Any]) -> str:
        """Generate proposal submission email"""
        
        return f"""
        Hi {context.get('contact_name')},

        As promised, I'm attaching our comprehensive proposal for {context.get('company_name')}.

        This proposal outlines:
        • Our understanding of your challenges and requirements
        • Recommended solution approach
        • Expected outcomes and ROI
        • Investment and timeline
        • Next steps

        Key highlights:
        • Total investment: ${context.get('total_investment', 50000):,.2f}
        • Expected ROI: {context.get('expected_roi', '300%')} in first year
        • Implementation timeline: {context.get('timeline', '3-4 months')}

        I'm available to discuss any questions you may have. Would you prefer to schedule 
        a call this week to review the proposal together?

        The proposal is valid until {context.get('validity_date', '30 days from today')}.

        Best regards,
        Sales Team
        """
    
    async def _generate_proposal_follow_up(self, context: Dict[str, Any]) -> str:
        """Generate proposal follow-up email"""
        
        days_since_proposal = context.get('days_since_proposal', 7)
        
        return f"""
        Hi {context.get('contact_name')},

        I wanted to follow up on the proposal we submitted {days_since_proposal} days ago for {context.get('company_name')}.

        I hope you've had a chance to review it with your team. I'm here to answer any questions 
        or address any concerns you might have.

        Some common questions I often get at this stage:
        • Implementation timeline and resource requirements
        • ROI projections and success metrics
        • Ongoing support and maintenance
        • References from similar projects

        Would it be helpful to schedule a brief call to discuss these topics?

        I'm also happy to arrange a reference call with one of our similar clients if that would be valuable.

        Best regards,
        Sales Team
        """
    
    async def _calculate_optimal_send_time(self, context: Dict[str, Any]) -> str:
        """Calculate optimal time to send communication"""
        # Simple logic - can be enhanced with ML
        day_of_week = datetime.now().weekday()
        
        if day_of_week < 4:  # Monday-Thursday
            return "Tuesday-Thursday, 10:00 AM"
        else:
            return "Next Tuesday, 10:00 AM"
    
    async def _calculate_follow_up_date(self, communication_type: str) -> datetime:
        """Calculate when to follow up"""
        
        follow_up_intervals = {
            'initial_contact': 3,  # 3 days
            'qualification_follow_up': 7,  # 1 week
            'proposal_submission': 5,  # 5 days
            'follow_up_proposal': 7  # 1 week
        }
        
        days = follow_up_intervals.get(communication_type, 7)
        return datetime.now() + timedelta(days=days)

class SalesAgent(BaseAgent):
    """Specialized Sales Agent for lead qualification, proposals, and relationship management"""
    
    def __init__(self, agent_config: Dict[str, Any]):
        # Generate unique agent ID
        agent_id = f"sales_agent_{uuid.uuid4().hex[:8]}"
        super().__init__(agent_id, agent_config)
        
        # Initialize sales-specific components
        self.lead_qualification_engine = LeadQualificationEngine()
        self.proposal_generator = ProposalGenerator()
        self.relationship_manager = ClientRelationshipManager()
        
        # Sales performance tracking
        self.leads_qualified = 0
        self.proposals_generated = 0
        self.deals_closed = 0
        self.total_revenue_generated = 0.0
        self.average_deal_size = 0.0
        self.conversion_rate = 0.0
        
        # Active opportunities and leads
        self.active_leads: Dict[str, Lead] = {}
        self.active_opportunities: Dict[str, SalesOpportunity] = {}
        self.active_proposals: Dict[str, Proposal] = {}
    
    def initialize_capabilities(self) -> CapabilitySet:
        """Initialize sales-specific capabilities"""
        return CapabilitySet(
            capabilities=[
                'lead_qualification',
                'proposal_development',
                'client_relationship_management',
                'sales_pipeline_management',
                'negotiation_support',
                'sales_analytics',
                'revenue_forecasting',
                'competitive_positioning',
                'closing_optimization',
                'account_management'
            ],
            proficiency_levels={
                'lead_qualification': 0.9,
                'proposal_development': 0.85,
                'client_relationship_management': 0.9,
                'sales_pipeline_management': 0.8,
                'negotiation_support': 0.75,
                'sales_analytics': 0.7,
                'revenue_forecasting': 0.75,
                'competitive_positioning': 0.8,
                'closing_optimization': 0.8,
                'account_management': 0.85
            }
        )
    
    async def process_task(self, task: Task) -> TaskResult:
        """Process sales-specific tasks"""
        
        try:
            self.logger.info(f"Sales Agent processing task: {task.title}")
            
            if task.task_type == 'lead_qualification':
                return await self._handle_lead_qualification_task(task)
            elif task.task_type == 'proposal_development':
                return await self._handle_proposal_development_task(task)
            elif task.task_type == 'relationship_management':
                return await self._handle_relationship_management_task(task)
            elif task.task_type == 'pipeline_management':
                return await self._handle_pipeline_management_task(task)
            elif task.task_type == 'negotiation_support':
                return await self._handle_negotiation_support_task(task)
            elif task.task_type == 'sales_analytics':
                return await self._handle_sales_analytics_task(task)
            else:
                return await self._handle_generic_sales_task(task)
                
        except Exception as e:
            self.logger.error(f"Error processing sales task {task.task_id}: {str(e)}")
            return TaskResult(
                task_id=task.task_id,
                status='failed',
                error_message=str(e)
            )
    
    def validate_task_compatibility(self, task: Task) -> ValidationResult:
        """Validate sales task compatibility"""
        
        sales_task_types = [
            'lead_qualification', 'proposal_development', 'relationship_management',
            'pipeline_management', 'negotiation_support', 'sales_analytics',
            'revenue_forecasting', 'competitive_positioning', 'closing_optimization',
            'account_management'
        ]
        
        if task.task_type not in sales_task_types:
            return ValidationResult(
                is_valid=False,
                rejection_reason=f"Task type '{task.task_type}' not supported by Sales Agent",
                alternatives=['MarketingAgent', 'CustomerServiceAgent', 'ResearchAgent']
            )
        
        # Check capability match
        capability_match = self.capabilities.has_capability(task.task_type, min_proficiency=0.6)
        
        return ValidationResult(
            is_valid=capability_match,
            confidence_level=self.capabilities.proficiency_levels.get(task.task_type, 0.7)
        )
    
    async def _handle_lead_qualification_task(self, task: Task) -> TaskResult:
        """Handle lead qualification tasks"""
        
        # Extract lead information
        lead_data = task.requirements.get('lead_data', {})
        qualification_data = task.requirements.get('qualification_data', {})
        
        # Create lead object
        lead = Lead(
            lead_id=lead_data.get('lead_id', f"lead_{uuid.uuid4().hex[:8]}"),
            contact_name=lead_data.get('contact_name', 'Unknown'),
            company_name=lead_data.get('company_name', 'Unknown Company'),
            email=lead_data.get('email', ''),
            phone=lead_data.get('phone'),
            job_title=lead_data.get('job_title'),
            company_size=lead_data.get('company_size'),
            industry=lead_data.get('industry'),
            lead_source=lead_data.get('lead_source')
        )
        
        # Qualify the lead
        qualification_result = await self.lead_qualification_engine.qualify_lead(lead, qualification_data)
        
        # Update lead with qualification results
        lead.score = qualification_result['qualification_score']
        lead.status = LeadStatus.QUALIFIED if qualification_result['qualification_status'] in ['qualified', 'highly_qualified'] else LeadStatus.NURTURING
        lead.qualification_notes = f"Score: {qualification_result['qualification_score']}/100, Status: {qualification_result['qualification_status']}"
        
        # Store lead
        self.active_leads[lead.lead_id] = lead
        self.leads_qualified += 1
        
        # Generate follow-up communication if qualified
        follow_up_communication = None
        if qualification_result['qualification_status'] in ['qualified', 'highly_qualified']:
            follow_up_communication = await self.relationship_manager.generate_communication(
                'qualification_follow_up',
                {
                    'contact_name': lead.contact_name,
                    'company_name': lead.company_name,
                    'discussion_topic': task.requirements.get('discussion_topic', 'your business needs'),
                    'priority_1': qualification_data.get('priority_1', 'Operational efficiency'),
                    'priority_2': qualification_data.get('priority_2', 'Cost reduction'),
                    'priority_3': qualification_data.get('priority_3', 'Market expansion'),
                    'proposal_delivery_date': (datetime.now() + timedelta(days=3)).strftime('%A')
                }
            )
        
        return TaskResult(
            task_id=task.task_id,
            status='completed',
            deliverables={
                'lead_qualification': {
                    'lead_id': lead.lead_id,
                    'qualification_score': qualification_result['qualification_score'],
                    'qualification_status': qualification_result['qualification_status'],
                    'priority': qualification_result['priority'],
                    'insights': qualification_result['insights'],
                    'next_steps': qualification_result['next_steps'],
                    'recommended_actions': qualification_result['recommended_actions']
                },
                'follow_up_communication': follow_up_communication,
                'lead_summary': {
                    'company': lead.company_name,
                    'contact': lead.contact_name,
                    'score': lead.score,
                    'status': lead.status.value
                }
            },
            quality_metrics={
                'qualification_thoroughness': 0.9,
                'lead_score_accuracy': 0.85,
                'action_plan_quality': 0.8
            },
            recommendations=[
                f"Lead scored {qualification_result['qualification_score']}/100",
                f"Qualification status: {qualification_result['qualification_status']}",
                f"Priority level: {qualification_result['priority']}",
                f"Next steps: {', '.join(qualification_result['next_steps'][:2])}"
            ]
        )
    
    async def _handle_proposal_development_task(self, task: Task) -> TaskResult:
        """Handle proposal development tasks"""
        
        # Get opportunity information
        opportunity_data = task.requirements.get('opportunity_data', {})
        proposal_requirements = task.requirements.get('proposal_requirements', {})
        
        # Create or get existing opportunity
        opportunity_id = opportunity_data.get('opportunity_id', f"opp_{uuid.uuid4().hex[:8]}")
        
        if opportunity_id in self.active_opportunities:
            opportunity = self.active_opportunities[opportunity_id]
        else:
            # Create new opportunity from lead
            lead_id = opportunity_data.get('lead_id')
            if lead_id and lead_id in self.active_leads:
                lead = self.active_leads[lead_id]
            else:
                # Create placeholder lead
                lead = Lead(
                    lead_id=lead_id or f"lead_{uuid.uuid4().hex[:8]}",
                    contact_name=opportunity_data.get('contact_name', 'Unknown'),
                    company_name=opportunity_data.get('company_name', 'Unknown Company'),
                    email=opportunity_data.get('email', '')
                )
            
            opportunity = SalesOpportunity(
                opportunity_id=opportunity_id,
                lead=lead,
                deal_stage=DealStage.PROPOSAL,
                opportunity_value=opportunity_data.get('opportunity_value', 50000),
                probability=opportunity_data.get('probability', 0.3),
                expected_close_date=datetime.strptime(
                    opportunity_data.get('expected_close_date', (datetime.now() + timedelta(days=60)).strftime('%Y-%m-%d')), 
                    '%Y-%m-%d'
                ),
                products_services=opportunity_data.get('products_services', ['Consulting Services'])
            )
            
            self.active_opportunities[opportunity_id] = opportunity
        
        # Generate proposal
        proposal = await self.proposal_generator.generate_proposal(opportunity, proposal_requirements)
        
        # Store proposal
        self.active_proposals[proposal.proposal_id] = proposal
        self.proposals_generated += 1
        
        # Generate proposal submission communication
        submission_communication = await self.relationship_manager.generate_communication(
            'proposal_submission',
            {
                'contact_name': opportunity.lead.contact_name,
                'company_name': opportunity.lead.company_name,
                'total_investment': opportunity.opportunity_value,
                'expected_roi': proposal_requirements.get('expected_roi', '300%'),
                'timeline': proposal_requirements.get('project_duration', '3-4 months'),
                'validity_date': proposal.validity_period.strftime('%B %d, %Y')
            }
        )
        
        return TaskResult(
            task_id=task.task_id,
            status='completed',
            deliverables={
                'proposal': {
                    'proposal_id': proposal.proposal_id,
                    'client_name': proposal.client_name,
                    'title': proposal.proposal_title,
                    'executive_summary': proposal.executive_summary,
                    'solution_description': proposal.solution_description,
                    'pricing': proposal.pricing,
                    'timeline': {k: v.isoformat() for k, v in proposal.timeline.items()},
                    'terms_conditions': proposal.terms_conditions,
                    'validity_period': proposal.validity_period.isoformat()
                },
                'submission_communication': submission_communication,
                'opportunity_update': {
                    'opportunity_id': opportunity.opportunity_id,
                    'stage': opportunity.deal_stage.value,
                    'value': opportunity.opportunity_value,
                    'probability': opportunity.probability
                }
            },
            quality_metrics={
                'proposal_completeness': 0.95,
                'customization_level': 0.85,
                'value_proposition_strength': 0.9,
                'pricing_competitiveness': 0.8
            },
            recommendations=[
                f"Proposal generated for ${opportunity.opportunity_value:,.2f} opportunity",
                f"Valid until {proposal.validity_period.strftime('%B %d, %Y')}",
                "Follow up within 5 business days",
                "Schedule presentation call with decision makers"
            ]
        )
    
    async def _handle_relationship_management_task(self, task: Task) -> TaskResult:
        """Handle client relationship management tasks"""
        
        communication_type = task.requirements.get('communication_type', 'follow_up')
        context = task.requirements.get('context', {})
        
        # Generate communication
        communication = await self.relationship_manager.generate_communication(communication_type, context)
        
        # Schedule follow-up if needed
        follow_up_scheduled = None
        if task.requirements.get('schedule_follow_up', True):
            follow_up_scheduled = {
                'follow_up_date': communication['follow_up_date'].isoformat(),
                'communication_type': 'follow_up',
                'priority': 'medium'
            }
        
        return TaskResult(
            task_id=task.task_id,
            status='completed',
            deliverables={
                'communication': communication,
                'follow_up_scheduled': follow_up_scheduled,
                'relationship_notes': f"Generated {communication_type} communication for {context.get('company_name', 'client')}"
            },
            quality_metrics={
                'personalization_level': 0.8,
                'message_clarity': 0.9,
                'call_to_action_strength': 0.85
            }
        )
    
    async def _handle_pipeline_management_task(self, task: Task) -> TaskResult:
        """Handle sales pipeline management tasks"""
        
        # Generate pipeline analysis
        pipeline_analysis = {
            'total_opportunities': len(self.active_opportunities),
            'total_pipeline_value': sum(opp.opportunity_value for opp in self.active_opportunities.values()),
            'weighted_pipeline_value': sum(
                opp.opportunity_value * opp.probability 
                for opp in self.active_opportunities.values()
            ),
            'average_deal_size': self.average_deal_size,
            'conversion_rate': self.conversion_rate,
            'opportunities_by_stage': self._analyze_opportunities_by_stage(),
            'top_opportunities': self._identify_top_opportunities(),
            'at_risk_opportunities': self._identify_at_risk_opportunities(),
            'pipeline_health_score': self._calculate_pipeline_health_score()
        }
        
        # Generate recommendations
        recommendations = await self._generate_pipeline_recommendations(pipeline_analysis)
        
        return TaskResult(
            task_id=task.task_id,
            status='completed',
            deliverables={
                'pipeline_analysis': pipeline_analysis,
                'recommendations': recommendations,
                'action_items': await self._generate_pipeline_action_items(pipeline_analysis)
            },
            quality_metrics={
                'analysis_depth': 0.9,
                'recommendation_quality': 0.85,
                'actionability': 0.9
            }
        )
    
    async def _handle_negotiation_support_task(self, task: Task) -> TaskResult:
        """Handle negotiation support tasks"""
        
        negotiation_context = task.requirements.get('negotiation_context', {})
        
        # Generate negotiation strategy
        negotiation_strategy = {
            'negotiation_objectives': negotiation_context.get('objectives', ['Close deal', 'Maintain margin']),
            'client_motivations': negotiation_context.get('client_motivations', ['Cost reduction', 'Quick implementation']),
            'our_strengths': ['Proven track record', 'Comprehensive solution', 'Strong support'],
            'potential_concessions': [
                {'concession': 'Extended payment terms', 'impact': 'Low', 'value_to_client': 'High'},
                {'concession': '5% discount', 'impact': 'Medium', 'value_to_client': 'Medium'},
                {'concession': 'Additional training', 'impact': 'Low', 'value_to_client': 'High'}
            ],
            'walk_away_point': negotiation_context.get('minimum_deal_value', 0),
            'negotiation_tactics': [
                'Anchor high on value delivery',
                'Bundle services for better perceived value',
                'Use time pressure appropriately',
                'Focus on ROI and business outcomes'
            ]
        }
        
        return TaskResult(
            task_id=task.task_id,
            status='completed',
            deliverables={
                'negotiation_strategy': negotiation_strategy,
                'talking_points': await self._generate_negotiation_talking_points(negotiation_context),
                'objection_responses': await self._generate_objection_responses()
            },
            quality_metrics={
                'strategy_comprehensiveness': 0.9,
                'tactical_depth': 0.85
            }
        )
    
    async def _handle_sales_analytics_task(self, task: Task) -> TaskResult:
        """Handle sales analytics tasks"""
        
        analytics_period = task.requirements.get('period', 'current_month')
        
        sales_analytics = {
            'performance_summary': {
                'leads_qualified': self.leads_qualified,
                'proposals_generated': self.proposals_generated,
                'deals_closed': self.deals_closed,
                'total_revenue': self.total_revenue_generated,
                'average_deal_size': self.average_deal_size,
                'conversion_rate': self.conversion_rate
            },
            'pipeline_metrics': {
                'total_opportunities': len(self.active_opportunities),
                'pipeline_value': sum(opp.opportunity_value for opp in self.active_opportunities.values()),
                'weighted_pipeline': sum(
                    opp.opportunity_value * opp.probability 
                    for opp in self.active_opportunities.values()
                )
            },
            'activity_metrics': {
                'proposals_in_review': len([p for p in self.active_proposals.values() if p.status == 'submitted']),
                'follow_ups_needed': len([opp for opp in self.active_opportunities.values() 
                                        if opp.deal_stage == DealStage.PROPOSAL]),
                'opportunities_closing_soon': len([
                    opp for opp in self.active_opportunities.values() 
                    if opp.expected_close_date <= datetime.now() + timedelta(days=30)
                ])
            }
        }
        
        return TaskResult(
            task_id=task.task_id,
            status='completed',
            deliverables={
                'sales_analytics': sales_analytics,
                'performance_trends': await self._analyze_performance_trends(),
                'forecasting': await self._generate_sales_forecast()
            },
            quality_metrics={
                'data_accuracy': 0.95,
                'insight_depth': 0.8
            }
        )
    
    async def _handle_generic_sales_task(self, task: Task) -> TaskResult:
        """Handle generic sales tasks"""
        
        return TaskResult(
            task_id=task.task_id,
            status='completed',
            deliverables={
                'task_analysis': f"Processed {task.task_type} task",
                'recommendations': [
                    'Task completed with standard sales approach',
                    'Consider using specialized task type for enhanced results'
                ]
            },
            quality_metrics={'completion_quality': 0.7}
        )
    
    # Helper methods for pipeline analysis
    def _analyze_opportunities_by_stage(self) -> Dict[str, int]:
        """Analyze opportunities by deal stage"""
        stage_counts = {}
        for stage in DealStage:
            stage_counts[stage.value] = len([
                opp for opp in self.active_opportunities.values() 
                if opp.deal_stage == stage
            ])
        return stage_counts
    
    def _identify_top_opportunities(self) -> List[Dict[str, Any]]:
        """Identify top opportunities by value"""
        top_opps = sorted(
            self.active_opportunities.values(),
            key=lambda opp: opp.opportunity_value * opp.probability,
            reverse=True
        )[:5]
        
        return [
            {
                'opportunity_id': opp.opportunity_id,
                'company': opp.lead.company_name,
                'value': opp.opportunity_value,
                'probability': opp.probability,
                'weighted_value': opp.opportunity_value * opp.probability,
                'stage': opp.deal_stage.value,
                'close_date': opp.expected_close_date.isoformat()
            }
            for opp in top_opps
        ]
    
    def _identify_at_risk_opportunities(self) -> List[Dict[str, Any]]:
        """Identify opportunities at risk"""
        at_risk = []
        
        for opp in self.active_opportunities.values():
            risk_factors = []
            
            # Check if close date is approaching without recent activity
            if opp.expected_close_date <= datetime.now() + timedelta(days=14):
                risk_factors.append('Close date approaching')
            
            # Check if stuck in stage too long
            # This would require activity tracking in real implementation
            if opp.deal_stage == DealStage.PROPOSAL:
                risk_factors.append('Long time in proposal stage')
            
            if risk_factors:
                at_risk.append({
                    'opportunity_id': opp.opportunity_id,
                    'company': opp.lead.company_name,
                    'value': opp.opportunity_value,
                    'risk_factors': risk_factors,
                    'recommended_actions': ['Schedule follow-up call', 'Send proposal reminder']
                })
        
        return at_risk
    
    def _calculate_pipeline_health_score(self) -> float:
        """Calculate overall pipeline health score"""
        if not self.active_opportunities:
            return 0.5
        
        # Simple scoring based on stage distribution and activity
        total_opps = len(self.active_opportunities)
        early_stage = len([opp for opp in self.active_opportunities.values() 
                          if opp.deal_stage in [DealStage.PROSPECTING, DealStage.DISCOVERY]])
        late_stage = len([opp for opp in self.active_opportunities.values() 
                         if opp.deal_stage in [DealStage.PROPOSAL, DealStage.NEGOTIATION, DealStage.CLOSING]])
        
        stage_balance = min(early_stage, late_stage) / max(early_stage, late_stage) if max(early_stage, late_stage) > 0 else 0
        
        # Factor in weighted pipeline value
        weighted_value = sum(opp.opportunity_value * opp.probability for opp in self.active_opportunities.values())
        value_score = min(weighted_value / 100000, 1.0)  # Normalize to $100k
        
        health_score = (stage_balance * 0.4) + (value_score * 0.6)
        return min(health_score, 1.0)
    
    async def _generate_pipeline_recommendations(self, pipeline_analysis: Dict[str, Any]) -> List[str]:
        """Generate pipeline management recommendations"""
        recommendations = []
        
        if pipeline_analysis['total_opportunities'] < 5:
            recommendations.append('Increase lead generation activities - pipeline needs more opportunities')
        
        if pipeline_analysis['pipeline_health_score'] < 0.6:
            recommendations.append('Focus on moving opportunities through stages more effectively')
        
        if pipeline_analysis.get('at_risk_opportunities'):
            recommendations.append(f"{len(pipeline_analysis['at_risk_opportunities'])} opportunities need immediate attention")
        
        if pipeline_analysis['weighted_pipeline_value'] < pipeline_analysis['total_pipeline_value'] * 0.3:
            recommendations.append('Work on improving deal probabilities through better qualification')
        
        return recommendations if recommendations else ['Pipeline is performing well - maintain current activities']
    
    async def _generate_pipeline_action_items(self, pipeline_analysis: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Generate specific action items for pipeline management"""
        action_items = []
        
        # Actions for at-risk opportunities
        for at_risk in pipeline_analysis.get('at_risk_opportunities', []):
            action_items.append({
                'action': f"Follow up on {at_risk['company']} opportunity",
                'priority': 'high',
                'timeline': 'This week',
                'opportunity_value': at_risk['value']
            })
        
        # Actions for top opportunities
        for top_opp in pipeline_analysis.get('top_opportunities', [])[:3]:
            if top_opp['stage'] == 'proposal':
                action_items.append({
                    'action': f"Schedule presentation for {top_opp['company']}",
                    'priority': 'high',
                    'timeline': 'Next 3 days',
                    'opportunity_value': top_opp['value']
                })
        
        return action_items
    
    async def _generate_negotiation_talking_points(self, context: Dict[str, Any]) -> List[str]:
        """Generate negotiation talking points"""
        return [
            "Focus on ROI and business value delivered",
            "Highlight our unique differentiators and proven track record",
            "Address cost concerns by emphasizing long-term savings",
            "Use case studies and references to build confidence",
            "Create urgency around limited availability or pricing"
        ]
    
    async def _generate_objection_responses(self) -> Dict[str, str]:
        """Generate responses to common objections"""
        return {
            "price_too_high": "I understand budget is a concern. Let's look at the ROI projections and how this investment pays for itself within 6 months through efficiency gains.",
            "need_to_think_about_it": "That's completely understandable. What specific aspects would you like to discuss further? I'm happy to provide additional information.",
            "comparing_other_vendors": "Smart approach. What criteria are most important in your evaluation? I'd be happy to show how we compare on those key factors.",
            "not_the_right_time": "When would be a better time? Let's discuss what needs to happen for this to become a priority.",
            "need_approval": "Who else is involved in the approval process? I'd be happy to prepare materials for your internal discussions."
        }
    
    async def _analyze_performance_trends(self) -> Dict[str, Any]:
        """Analyze sales performance trends"""
        return {
            'lead_qualification_trend': 'Increasing',
            'proposal_win_rate': 0.65,
            'average_sales_cycle': 45,  # days
            'month_over_month_growth': 0.15,
            'forecast_accuracy': 0.85
        }
    
    async def _generate_sales_forecast(self) -> Dict[str, Any]:
        """Generate sales forecast"""
        weighted_pipeline = sum(
            opp.opportunity_value * opp.probability 
            for opp in self.active_opportunities.values()
        )
        
        return {
            'current_month_forecast': weighted_pipeline * 0.3,
            'next_month_forecast': weighted_pipeline * 0.4,
            'quarter_forecast': weighted_pipeline * 0.7,
            'confidence_level': 'Medium',
            'key_assumptions': [
                'Historical win rates remain consistent',
                'No major market disruptions',
                'Current pipeline velocity maintained'
            ]
        }