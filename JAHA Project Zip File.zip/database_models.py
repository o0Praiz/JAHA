"""
Database Models and Schema Implementation
JAH Agency - Data Layer
"""

from sqlalchemy import create_engine, Column, String, Integer, Float, DateTime, Text, Boolean, JSON, ForeignKey, Enum
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship
from datetime import datetime
import enum
import uuid

Base = declarative_base()

class AgentStatusEnum(enum.Enum):
    ACTIVE = "active"
    IDLE = "idle"
    BUSY = "busy"
    MAINTENANCE = "maintenance"
    TERMINATED = "terminated"

class TaskStatusEnum(enum.Enum):
    PENDING = "pending"
    ASSIGNED = "assigned"
    IN_PROGRESS = "in_progress"
    REVIEW = "review"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"

class ComplexityLevelEnum(enum.Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

class Agent(Base):
    __tablename__ = 'agents'
    
    agent_id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    agent_name = Column(String(255), nullable=False)
    agent_type = Column(String(100), nullable=False)
    status = Column(Enum(AgentStatusEnum), default=AgentStatusEnum.IDLE)
    capabilities = Column(JSON, nullable=False)
    resource_allocation = Column(Float, default=0.0)
    performance_score = Column(Float, default=0.0)
    creation_date = Column(DateTime, default=datetime.utcnow)
    last_activity = Column(DateTime, default=datetime.utcnow)
    configuration = Column(JSON)
    parent_agent_id = Column(String(36), ForeignKey('agents.agent_id'))
    
    # Relationships
    children = relationship("Agent", backref="parent", remote_side=[agent_id])
    assigned_tasks = relationship("Task", back_populates="assigned_agent")
    performance_metrics = relationship("AgentPerformanceMetric", back_populates="agent")

class Task(Base):
    __tablename__ = 'tasks'
    
    task_id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    title = Column(String(500), nullable=False)
    description = Column(Text, nullable=False)
    task_type = Column(String(100), nullable=False)
    complexity_level = Column(Enum(ComplexityLevelEnum), nullable=False)
    priority_score = Column(Integer, default=50)
    assigned_agent_id = Column(String(36), ForeignKey('agents.agent_id'))
    status = Column(Enum(TaskStatusEnum), default=TaskStatusEnum.PENDING)
    requirements = Column(JSON)
    deliverables = Column(JSON)
    creation_date = Column(DateTime, default=datetime.utcnow)
    assignment_date = Column(DateTime)
    start_date = Column(DateTime)
    completion_date = Column(DateTime)
    deadline = Column(DateTime)
    estimated_hours = Column(Float)
    actual_hours = Column(Float)
    quality_score = Column(Float)
    stakeholder_satisfaction = Column(Float)
    revenue_potential = Column(Float)
    project_id = Column(String(36), ForeignKey('projects.project_id'))
    
    # Relationships
    assigned_agent = relationship("Agent", back_populates="assigned_tasks")
    project = relationship("Project", back_populates="tasks")

class Project(Base):
    __tablename__ = 'projects'
    
    project_id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    project_name = Column(String(255), nullable=False)
    client_name = Column(String(255))
    project_type = Column(String(100), nullable=False)
    status = Column(String(50), default='planning')
    description = Column(Text)
    start_date = Column(DateTime)
    end_date = Column(DateTime)
    budget = Column(Float)
    revenue_target = Column(Float)
    actual_revenue = Column(Float, default=0.0)
    project_manager_agent_id = Column(String(36), ForeignKey('agents.agent_id'))
    stakeholder_contact = Column(String(255))
    creation_date = Column(DateTime, default=datetime.utcnow)
    completion_date = Column(DateTime)
    
    # Relationships
    tasks = relationship("Task", back_populates="project")
    project_manager = relationship("Agent")

class Account(Base):
    __tablename__ = 'accounts'
    
    account_id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    account_name = Column(String(255), nullable=False)
    account_type = Column(String(50), nullable=False)
    current_balance = Column(Float, default=0.0)
    currency = Column(String(3), default='USD')
    account_number = Column(String(50))
    institution_name = Column(String(255))
    status = Column(String(20), default='active')
    creation_date = Column(DateTime, default=datetime.utcnow)
    last_transaction_date = Column(DateTime)
    
    # Relationships
    transactions = relationship("FinancialTransaction", back_populates="account")

class FinancialTransaction(Base):
    __tablename__ = 'financial_transactions'
    
    transaction_id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    account_id = Column(String(36), ForeignKey('accounts.account_id'), nullable=False)
    transaction_type = Column(String(20), nullable=False)  # credit, debit
    amount = Column(Float, nullable=False)
    category = Column(String(50), nullable=False)
    subcategory = Column(String(100))
    description = Column(Text, nullable=False)
    reference_number = Column(String(100))
    transaction_date = Column(DateTime, default=datetime.utcnow)
    processed_date = Column(DateTime)
    validation_status = Column(String(20), default='pending')
    related_task_id = Column(String(36), ForeignKey('tasks.task_id'))
    related_project_id = Column(String(36), ForeignKey('projects.project_id'))
    related_agent_id = Column(String(36), ForeignKey('agents.agent_id'))
    external_reference = Column(String(255))
    
    # Relationships
    account = relationship("Account", back_populates="transactions")
    related_task = relationship("Task")
    related_project = relationship("Project")
    related_agent = relationship("Agent")

class AgentCommunication(Base):
    __tablename__ = 'agent_communications'
    
    communication_id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    sender_agent_id = Column(String(36), ForeignKey('agents.agent_id'), nullable=False)
    recipient_agent_id = Column(String(36), ForeignKey('agents.agent_id'))
    communication_type = Column(String(50), nullable=False)
    subject = Column(String(255), nullable=False)
    message_content = Column(Text, nullable=False)
    priority = Column(String(20), default='normal')
    related_task_id = Column(String(36), ForeignKey('tasks.task_id'))
    related_project_id = Column(String(36), ForeignKey('projects.project_id'))
    timestamp = Column(DateTime, default=datetime.utcnow)
    read_status = Column(Boolean, default=False)
    response_required = Column(Boolean, default=False)
    response_deadline = Column(DateTime)
    
    # Relationships
    sender = relationship("Agent", foreign_keys=[sender_agent_id])
    recipient = relationship("Agent", foreign_keys=[recipient_agent_id])

class SystemLog(Base):
    __tablename__ = 'system_logs'
    
    log_id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    timestamp = Column(DateTime, default=datetime.utcnow)
    log_level = Column(String(20), nullable=False)
    source_component = Column(String(100), nullable=False)
    source_agent_id = Column(String(36), ForeignKey('agents.agent_id'))
    event_type = Column(String(100), nullable=False)
    message = Column(Text, nullable=False)
    additional_data = Column(JSON)
    session_id = Column(String(36))
    user_id = Column(String(36))
    ip_address = Column(String(45))
    
    # Relationships
    source_agent = relationship("Agent")

class AgentPerformanceMetric(Base):
    __tablename__ = 'agent_performance_metrics'
    
    metric_id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    agent_id = Column(String(36), ForeignKey('agents.agent_id'), nullable=False)
    measurement_date = Column(DateTime, nullable=False)
    tasks_completed = Column(Integer, default=0)
    tasks_failed = Column(Integer, default=0)
    average_completion_time = Column(Float)
    quality_score_average = Column(Float)
    resource_utilization = Column(Float)
    revenue_generated = Column(Float, default=0.0)
    cost_incurred = Column(Float, default=0.0)
    efficiency_rating = Column(Float)
    stakeholder_satisfaction = Column(Float)
    improvement_recommendations = Column(Text)
    
    # Relationships
    agent = relationship("Agent", back_populates="performance_metrics")

class RevenueOpportunity(Base):
    __tablename__ = 'revenue_opportunities'
    
    opportunity_id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    opportunity_name = Column(String(255), nullable=False)
    source_platform = Column(String(100), nullable=False)
    opportunity_type = Column(String(50), nullable=False)
    description = Column(Text, nullable=False)
    estimated_value = Column(Float, nullable=False)
    effort_required = Column(Float)
    probability_score = Column(Float)
    discovery_date = Column(DateTime, default=datetime.utcnow)
    deadline = Column(DateTime)
    status = Column(String(20), default='identified')
    assigned_agent_id = Column(String(36), ForeignKey('agents.agent_id'))
    client_information = Column(JSON)
    requirements = Column(JSON)
    competitive_analysis = Column(JSON)
    proposal_submitted = Column(Boolean, default=False)
    proposal_date = Column(DateTime)
    decision_date = Column(DateTime)
    actual_value = Column(Float)
    
    # Relationships
    assigned_agent = relationship("Agent")

# Database Manager Class
class DatabaseManager:
    def __init__(self, database_url: str = "sqlite:///jah_agency.db"):
        self.database_url = database_url
        self.engine = create_engine(database_url)
        self.SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=self.engine)
    
    def create_tables(self):
        """Create all database tables"""
        Base.metadata.create_all(bind=self.engine)
    
    def get_session(self):
        """Get database session"""
        return self.SessionLocal()
    
    def initialize_system_data(self):
        """Initialize system with default data"""
        session = self.get_session()
        try:
            # Create primary revenue account
            primary_account = Account(
                account_name="Primary Revenue Account",
                account_type="primary_revenue",
                current_balance=0.0,
                currency="USD",
                status="active"
            )
            session.add(primary_account)
            
            # Create operational expense account
            operational_account = Account(
                account_name="Operational Expense Account", 
                account_type="operational_expense",
                current_balance=0.0,
                currency="USD",
                status="active"
            )
            session.add(operational_account)
            
            # Create primary JAH agent record
            primary_agent = Agent(
                agent_id="primary_jah_agent",
                agent_name="Primary JAH Agent",
                agent_type="PrimaryJAHAgent",
                status=AgentStatusEnum.ACTIVE,
                capabilities=[
                    "strategic_planning",
                    "task_analysis", 
                    "agent_coordination",
                    "resource_optimization",
                    "decision_making"
                ],
                performance_score=0.0
            )
            session.add(primary_agent)
            
            session.commit()
            print("System initialized with default data")
            
        except Exception as e:
            session.rollback()
            print(f"Error initializing system data: {e}")
        finally:
            session.close()

# Repository Classes for data access
class AgentRepository:
    def __init__(self, db_manager: DatabaseManager):
        self.db_manager = db_manager
    
    def create_agent(self, agent_data: dict) -> Agent:
        session = self.db_manager.get_session()
        try:
            agent = Agent(**agent_data)
            session.add(agent)
            session.commit()
            session.refresh(agent)
            return agent
        finally:
            session.close()
    
    def get_agent(self, agent_id: str) -> Agent:
        session = self.db_manager.get_session()
        try:
            return session.query(Agent).filter(Agent.agent_id == agent_id).first()
        finally:
            session.close()
    
    def get_agents_by_capability(self, capability: str) -> list:
        session = self.db_manager.get_session()
        try:
            # Using JSON contains for SQLite - adjust for other databases
            return session.query(Agent).filter(
                Agent.capabilities.contains(capability)
            ).all()
        finally:
            session.close()
    
    def update_agent_status(self, agent_id: str, status: AgentStatusEnum):
        session = self.db_manager.get_session()
        try:
            agent = session.query(Agent).filter(Agent.agent_id == agent_id).first()
            if agent:
                agent.status = status
                agent.last_activity = datetime.utcnow()
                session.commit()
        finally:
            session.close()

class TaskRepository:
    def __init__(self, db_manager: DatabaseManager):
        self.db_manager = db_manager
    
    def create_task(self, task_data: dict) -> Task:
        session = self.db_manager.get_session()
        try:
            task = Task(**task_data)
            session.add(task)
            session.commit()
            session.refresh(task)
            return task
        finally:
            session.close()
    
    def get_task(self, task_id: str) -> Task:
        session = self.db_manager.get_session()
        try:
            return session.query(Task).filter(Task.task_id == task_id).first()
        finally:
            session.close()
    
    def assign_task(self, task_id: str, agent_id: str):
        session = self.db_manager.get_session()
        try:
            task = session.query(Task).filter(Task.task_id == task_id).first()
            if task:
                task.assigned_agent_id = agent_id
                task.status = TaskStatusEnum.ASSIGNED
                task.assignment_date = datetime.utcnow()
                session.commit()
        finally:
            session.close()
    
    def update_task_status(self, task_id: str, status: TaskStatusEnum, completion_data: dict = None):
        session = self.db_manager.get_session()
        try:
            task = session.query(Task).filter(Task.task_id == task_id).first()
            if task:
                task.status = status
                if status == TaskStatusEnum.IN_PROGRESS and not task.start_date:
                    task.start_date = datetime.utcnow()
                elif status == TaskStatusEnum.COMPLETED:
                    task.completion_date = datetime.utcnow()
                    if completion_data:
                        task.quality_score = completion_data.get('quality_score')
                        task.actual_hours = completion_data.get('actual_hours')
                        task.deliverables = completion_data.get('deliverables')
                session.commit()
        finally:
            session.close()

class FinancialRepository:
    def __init__(self, db_manager: DatabaseManager):
        self.db_manager = db_manager
    
    def create_transaction(self, transaction_data: dict) -> FinancialTransaction:
        session = self.db_manager.get_session()
        try:
            transaction = FinancialTransaction(**transaction_data)
            session.add(transaction)
            
            # Update account balance
            account = session.query(Account).filter(
                Account.account_id == transaction.account_id
            ).first()
            
            if account:
                if transaction.transaction_type == 'credit':
                    account.current_balance += transaction.amount
                else:  # debit
                    account.current_balance -= transaction.amount
                account.last_transaction_date = datetime.utcnow()
            
            session.commit()
            session.refresh(transaction)
            return transaction
        finally:
            session.close()
    
    def get_account_balance(self, account_id: str) -> float:
        session = self.db_manager.get_session()
        try:
            account = session.query(Account).filter(Account.account_id == account_id).first()
            return account.current_balance if account else 0.0
        finally:
            session.close()
    
    def get_transactions_by_period(self, start_date: datetime, end_date: datetime) -> list:
        session = self.db_manager.get_session()
        try:
            return session.query(FinancialTransaction).filter(
                FinancialTransaction.transaction_date >= start_date,
                FinancialTransaction.transaction_date <= end_date
            ).all()
        finally:
            session.close()