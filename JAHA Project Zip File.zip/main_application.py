"""
JAH Agency Main Application
Entry point for the JAH Agency system
"""

import asyncio
import logging
import signal
import sys
from datetime import datetime
from typing import Dict, Any
import json

from src.core.base_agent import Task, ComplexityLevelEnum
from src.agents.primary_jah_agent import PrimaryJAHAgent
from src.database.models import DatabaseManager, AgentRepository, TaskRepository, FinancialRepository

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('jah_agency.log'),
        logging.StreamHandler(sys.stdout)
    ]
)

logger = logging.getLogger(__name__)

class JAHAgencySystem:
    """Main JAH Agency System Controller"""
    
    def __init__(self, config_file: str = "config/development.yaml"):
        self.config = self._load_config(config_file)
        self.db_manager = DatabaseManager(self.config.get('database_url', 'sqlite:///jah_agency.db'))
        
        # Initialize repositories
        self.agent_repository = AgentRepository(self.db_manager)
        self.task_repository = TaskRepository(self.db_manager)
        self.financial_repository = FinancialRepository(self.db_manager)
        
        # Initialize primary agent
        self.primary_agent = None
        self.system_running = False
        
        # System metrics
        self.system_metrics = {
            'start_time': None,
            'total_tasks_processed': 0,
            'active_agents': 0,
            'system_health': 'initializing'
        }
    
    def _load_config(self, config_file: str) -> Dict[str, Any]:
        """Load system configuration"""
        try:
            with open(config_file, 'r') as f:
                if config_file.endswith('.yaml') or config_file.endswith('.yml'):
                    import yaml
                    return yaml.safe_load(f)
                else:
                    return json.load(f)
        except FileNotFoundError:
            logger.warning(f"Config file {config_file} not found, using defaults")
            return self._get_default_config()
        except Exception as e:
            logger.error(f"Error loading config: {e}")
            return self._get_default_config()
    
    def _get_default_config(self) -> Dict[str, Any]:
        """Get default configuration"""
        return {
            'database_url': 'sqlite:///jah_agency.db',
            'primary_agent': {
                'performance_targets': {
                    'task_completion_rate': 0.95,
                    'average_quality_score': 0.85,
                    'response_time_target': 2.0
                },
                'resource_limits': {
                    'max_concurrent_tasks': 10,
                    'max_sub_agents': 50
                }
            },
            'system': {
                'log_level': 'INFO',
                'health_check_interval': 60,
                'metrics_collection_interval': 300
            }
        }
    
    async def initialize_system(self):
        """Initialize the JAH Agency system"""
        try:
            logger.info("Initializing JAH Agency System...")
            
            # Create database tables
            self.db_manager.create_tables()
            logger.info("Database tables created/verified")
            
            # Initialize system data
            self.db_manager.initialize_system_data()
            logger.info("System data initialized")
            
            # Create primary agent
            agent_config = self.config.get('primary_agent', {})
            self.primary_agent = PrimaryJAHAgent(agent_config)
            logger.info(f"Primary JAH Agent created: {self.primary_agent.agent_id}")
            
            # Update system metrics
            self.system_metrics['start_time'] = datetime.now()
            self.system_metrics['active_agents'] = 1
            self.system_metrics['system_health'] = 'healthy'
            
            logger.info("JAH Agency System initialized successfully")
            
        except Exception as e:
            logger.error(f"Failed to initialize system: {e}")
            raise
    
    async def start_system(self):
        """Start the JAH Agency system"""
        if not self.primary_agent:
            await self.initialize_system()
        
        logger.info("Starting JAH Agency System...")
        self.system_running = True
        
        # Start primary agent processing loop
        primary_agent_task = asyncio.create_task(
            self.primary_agent.start_processing_loop()
        )
        
        # Start system monitoring
        monitoring_task = asyncio.create_task(
            self._system_monitoring_loop()
        )
        
        # Start health check
        health_check_task = asyncio.create_task(
            self._health_check_loop()
        )
        
        try:
            # Run all tasks concurrently
            await asyncio.gather(
                primary_agent_task,
                monitoring_task,
                health_check_task
            )
        except asyncio.CancelledError:
            logger.info("System shutdown initiated")
        except Exception as e:
            logger.error(f"System error: {e}")
            raise
    
    async def shutdown_system(self):
        """Gracefully shutdown the system"""
        logger.info("Shutting down JAH Agency System...")
        self.system_running = False
        
        if self.primary_agent:
            self.primary_agent.status = self.primary_agent.status.TERMINATED
        
        # Update system metrics
        self.system_metrics['system_health'] = 'shutting_down'
        
        logger.info("JAH Agency System shutdown complete")
    
    async def _system_monitoring_loop(self):
        """Monitor system performance and metrics"""
        while self.system_running:
            try:
                # Collect system metrics
                await self._collect_system_metrics()
                
                # Check system health
                await self._check_system_health()
                
                # Wait for next monitoring cycle
                await asyncio.sleep(
                    self.config.get('system', {}).get('metrics_collection_interval', 300)
                )
                
            except Exception as e:
                logger.error(f"Error in system monitoring: {e}")
                await asyncio.sleep(60)  # Wait before retrying
    
    async def _health_check_loop(self):
        """Perform regular health checks"""
        while self.system_running:
            try:
                # Check primary agent health
                if self.primary_agent:
                    agent_health = self._check_agent_health(self.primary_agent)
                    if not agent_health['healthy']:
                        logger.warning(f"Primary agent health issue: {agent_health['issues']}")
                
                # Check database connectivity
                db_health = self._check_database_health()
                if not db_health['healthy']:
                    logger.error(f"Database health issue: {db_health['issues']}")
                
                # Wait for next health check
                await asyncio.sleep(
                    self.config.get('system', {}).get('health_check_interval', 60)
                )
                
            except Exception as e:
                logger.error(f"Error in health check: {e}")
                await asyncio.sleep(30)
    
    async def _collect_system_metrics(self):
        """Collect and update system metrics"""
        try:
            if self.primary_agent:
                performance_report = self.primary_agent.generate_performance_report()
                self.system_metrics.update({
                    'primary_agent_tasks_completed': performance_report['performance_metrics']['tasks_completed'],
                    'primary_agent_error_rate': performance_report['performance_metrics']['error_rate'],
                    'last_metrics_update': datetime.now()
                })
            
            logger.debug(f"System metrics updated: {self.system_metrics}")
            
        except Exception as e:
            logger.error(f"Error collecting system metrics: {e}")
    
    async def _check_system_health(self):
        """Check overall system health"""
        try:
            health_status = 'healthy'
            issues = []
            
            # Check primary agent
            if not self.primary_agent or self.primary_agent.status.value == 'terminated':
                health_status = 'critical'
                issues.append('Primary agent not running')
            
            # Check error rates
            if self.primary_agent and self.primary_agent.performance_metrics.error_rate > 0.2:
                health_status = 'degraded'
                issues.append('High error rate detected')
            
            self.system_metrics['system_health'] = health_status
            
            if issues:
                logger.warning(f"System health issues: {issues}")
            
        except Exception as e:
            logger.error(f"Error checking system health: {e}")
            self.system_metrics['system_health'] = 'unknown'
    
    def _check_agent_health(self, agent) -> Dict[str, Any]:
        """Check individual agent health"""
        health_info = {
            'healthy': True,
            'issues': []
        }
        
        try:
            # Check if agent is responsive
            if (datetime.now() - agent.last_activity).total_seconds() > 300:  # 5 minutes
                health_info['healthy'] = False
                health_info['issues'].append('Agent inactive for over 5 minutes')
            
            # Check error rate
            if agent.performance_metrics.error_rate > 0.15:
                health_info['healthy'] = False
                health_info['issues'].append('High error rate')
            
        except Exception as e:
            health_info['healthy'] = False
            health_info['issues'].append(f'Health check error: {e}')
        
        return health_info
    
    def _check_database_health(self) -> Dict[str, Any]:
        """Check database connectivity and health"""
        health_info = {
            'healthy': True,
            'issues': []
        }
        
        try:
            session = self.db_manager.get_session()
            # Simple query to test connectivity
            session.execute("SELECT 1")
            session.close()
        except Exception as e:
            health_info['healthy'] = False
            health_info['issues'].append(f'Database connectivity issue: {e}')
        
        return health_info
    
    async def submit_task(self, task_data: Dict[str, Any]) -> str:
        """Submit a new task to the system"""
        try:
            # Create task object
            task = Task(
                task_id=task_data.get('task_id', f"task_{datetime.now().strftime('%Y%m%d_%H%M%S')}"),
                title=task_data['title'],
                description=task_data['description'],
                task_type=task_data['task_type'],
                complexity_level=task_data.get('complexity_level', 'medium'),
                priority_score=task_data.get('priority_score', 50),
                requirements=task_data.get('requirements', {}),
                estimated_hours=task_data.get('estimated_hours'),
                deadline=task_data.get('deadline'),
                revenue_potential=task_data.get('revenue_potential')
            )
            
            # Submit to primary agent
            if self.primary_agent:
                assignment_response = await self.primary_agent.receive_task_assignment(task)
                
                if assignment_response.accepted:
                    logger.info(f"Task {task.task_id} accepted by primary agent")
                    self.system_metrics['total_tasks_processed'] += 1
                    return task.task_id
                else:
                    logger.warning(f"Task {task.task_id} rejected: {assignment_response.reason}")
                    return None
            else:
                logger.error("Primary agent not available")
                return None
                
        except Exception as e:
            logger.error(f"Error submitting task: {e}")
            return None
    
    def get_system_status(self) -> Dict[str, Any]:
        """Get current system status"""
        status = {
            'system_running': self.system_running,
            'system_metrics': self.system_metrics.copy(),
            'primary_agent_status': self.primary_agent.status.value if self.primary_agent else 'not_initialized'
        }
        
        if self.primary_agent:
            status['primary_agent_performance'] = self.primary_agent.generate_performance_report()
        
        return status

# Signal handlers for graceful shutdown
def signal_handler(system_instance):
    def handler(signum, frame):
        logger.info(f"Received signal {signum}, initiating shutdown...")
        asyncio.create_task(system_instance.shutdown_system())
    return handler

async def main():
    """Main entry point"""
    try:
        # Create system instance
        jah_system = JAHAgencySystem()
        
        # Setup signal handlers for graceful shutdown
        signal.signal(signal.SIGINT, signal_handler(jah_system))
        signal.signal(signal.SIGTERM, signal_handler(jah_system))
        
        # Start the system
        await jah_system.start_system()
        
    except KeyboardInterrupt:
        logger.info("Shutdown requested by user")
    except Exception as e:
        logger.error(f"System error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    # Example usage and testing
    async def test_system():
        """Test the JAH Agency System"""
        logger.info("Starting JAH Agency System Test...")
        
        # Create and initialize system
        system = JAHAgencySystem()
        await system.initialize_system()
        
        # Start system in background
        system_task = asyncio.create_task(system.start_system())
        
        # Wait a moment for system to start
        await asyncio.sleep(2)
        
        # Submit a test task
        test_task = {
            'title': 'Test Marketing Campaign',
            'description': 'Create a marketing campaign for product launch',
            'task_type': 'content_creation',
            'complexity_level': 'medium',
            'priority_score': 75,
            'requirements': {
                'target_audience': 'young professionals',
                'campaign_budget': 5000,
                'delivery_format': 'digital'
            },
            'estimated_hours': 8,
            'revenue_potential': 2500
        }
        
        task_id = await system.submit_task(test_task)
        if task_id:
            logger.info(f"Test task submitted successfully: {task_id}")
        else:
            logger.error("Failed to submit test task")
        
        # Wait and check system status
        await asyncio.sleep(5)
        status = system.get_system_status()
        logger.info(f"System Status: {json.dumps(status, indent=2, default=str)}")
        
        # Shutdown system
        await system.shutdown_system()
        system_task.cancel()
        
        logger.info("Test completed successfully")
    
    # Run the test
    asyncio.run(test_system())
