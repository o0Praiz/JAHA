# JAH Agency Setup and Installation Guide

## Requirements

### System Requirements
- Python 3.8 or higher
- 4GB RAM minimum (8GB recommended)
- 10GB free disk space
- SQLite (included with Python) or PostgreSQL/MySQL (optional)

### Python Dependencies

Create a `requirements.txt` file with the following contents:

```txt
# Core Dependencies
asyncio-mqtt==0.11.1
sqlalchemy==1.4.46
alembic==1.9.2
pydantic==1.10.4
fastapi==0.89.1
uvicorn==0.20.0

# Database Drivers
sqlite3  # Included with Python
psycopg2-binary==2.9.5  # PostgreSQL (optional)
pymysql==1.0.2  # MySQL (optional)

# Data Processing
pandas==1.5.3
numpy==1.24.1
requests==2.28.2

# AI/ML Dependencies (optional for advanced features)
openai==0.26.5
langchain==0.0.100
transformers==4.26.1

# Configuration and Utilities
pyyaml==6.0
python-dotenv==0.21.1
click==8.1.3

# Testing
pytest==7.2.1
pytest-asyncio==0.20.3
pytest-cov==4.0.0

# Development
black==23.1.0
flake8==6.0.0
mypy==1.0.0

# Logging and Monitoring
loguru==0.6.0
prometheus-client==0.15.0
```

## Installation Steps

### 1. Clone or Create Project Structure

```bash
mkdir jah_agency
cd jah_agency

# Create the directory structure
mkdir -p src/{core,agents,financial,database,api,utils,tests}
mkdir -p config docs scripts docker
```

### 2. Set Up Python Environment

```bash
# Create virtual environment
python -m venv venv

# Activate virtual environment
# On Windows:
venv\Scripts\activate
# On macOS/Linux:
source venv/bin/activate

# Upgrade pip
pip install --upgrade pip
```

### 3. Install Dependencies

```bash
# Install requirements
pip install -r requirements.txt
```

### 4. Configuration Setup

Create `config/development.yaml`:

```yaml
# JAH Agency Development Configuration

database_url: "sqlite:///jah_agency.db"

primary_agent:
  performance_targets:
    task_completion_rate: 0.95
    average_quality_score: 0.85
    response_time_target: 2.0
  resource_limits:
    max_concurrent_tasks: 10
    max_sub_agents: 50

system:
  log_level: "INFO"
  health_check_interval: 60
  metrics_collection_interval: 300

financial:
  primary_account_name: "Primary Revenue Account"
  operational_account_name: "Operational Expense Account"
  default_currency: "USD"
  
logging:
  level: "INFO"
  format: "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
  file: "jah_agency.log"
```

### 5. Environment Variables

Create `.env` file:

```bash
# Database Configuration
DATABASE_URL=sqlite:///jah_agency.db

# API Keys (add your actual keys)
OPENAI_API_KEY=your_openai_key_here
ANTHROPIC_API_KEY=your_anthropic_key_here

# System Configuration
LOG_LEVEL=INFO
ENVIRONMENT=development

# Security
SECRET_KEY=your_secret_key_here
```

### 6. Database Setup

```bash
# Initialize database
python -c "
from src.database.models import DatabaseManager
db = DatabaseManager()
db.create_tables()
db.initialize_system_data()
print('Database initialized successfully')
"
```

## Running the System

### 1. Basic Startup

```bash
# Run the main application
python main.py
```

### 2. Development Mode with Testing

```bash
# Run with test scenario
python -c "
import asyncio
from main import test_system
asyncio.run(test_system())
"
```

### 3. Interactive Testing

Create `test_client.py`:

```python
import asyncio
import json
from main import JAHAgencySystem

async def interactive_test():
    # Initialize system
    system = JAHAgencySystem()
    await system.initialize_system()
    
    # Start system
    system_task = asyncio.create_task(system.start_system())
    await asyncio.sleep(2)  # Wait for startup
    
    # Submit various test tasks
    tasks = [
        {
            'title': 'Market Research Analysis',
            'description': 'Analyze competitor pricing strategies',
            'task_type': 'market_research',
            'complexity_level': 'high',
            'priority_score': 80,
            'estimated_hours': 12
        },
        {
            'title': 'Website Development',
            'description': 'Create responsive landing page',
            'task_type': 'software_development', 
            'complexity_level': 'medium',
            'priority_score': 70,
            'estimated_hours': 16
        },
        {
            'title': 'Social Media Campaign',
            'description': 'Launch product awareness campaign',
            'task_type': 'content_creation',
            'complexity_level': 'medium',
            'priority_score': 60,
            'estimated_hours': 8
        }
    ]
    
    # Submit tasks
    for task in tasks:
        task_id = await system.submit_task(task)
        print(f"Submitted task: {task_id}")
        await asyncio.sleep(1)
    
    # Monitor system for a while
    for i in range(5):
        await asyncio.sleep(5)
        status = system.get_system_status()
        print(f"\n--- Status Update {i+1} ---")
        print(json.dumps(status, indent=2, default=str))
    
    # Shutdown
    await system.shutdown_system()
    system_task.cancel()

if __name__ == "__main__":
    asyncio.run(interactive_test())
```

Run with: `python test_client.py`

## Development Workflow

### 1. Adding New Agent Types

1. Create new agent class in `src/agents/`
2. Inherit from `BaseAgent`
3. Implement required abstract methods
4. Add to agent factory in `PrimaryJAHAgent`
5. Update database models if needed

### 2. Running Tests

```bash
# Run all tests
pytest

# Run with coverage
pytest --cov=src --cov-report=html

# Run specific test file
pytest src/tests/test_agents.py
```

### 3. Code Quality

```bash
# Format code
black src/

# Check linting
flake8 src/

# Type checking
mypy src/
```

## Deployment Options

### 1. Docker Deployment

Create `Dockerfile`:

```dockerfile
FROM python:3.9-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install -r requirements.txt

COPY . .

EXPOSE 8000

CMD ["python", "main.py"]
```

Build and run:

```bash
docker build -t jah-agency .
docker run -p 8000:8000 jah-agency
```

### 2. Production Configuration

Update `config/production.yaml`:

```yaml
database_url: "postgresql://user:password@localhost/jah_agency"

system:
  log_level: "WARNING"
  health_check_interval: 30
  metrics_collection_interval: 60

security:
  enable_authentication: true
  api_key_required: true
```

## Troubleshooting

### Common Issues

1. **Database Connection Errors**
   - Check database URL in configuration
   - Ensure database server is running (for PostgreSQL/MySQL)
   - Verify file permissions for SQLite

2. **Import Errors**
   - Ensure virtual environment is activated
   - Check that all requirements are installed
   - Verify Python path includes project directory

3. **Agent Communication Issues**
   - Check system logs for communication errors
   - Verify agent registration in database
   - Ensure proper async/await usage

### Debug Mode

Enable debug logging:

```python
import logging
logging.getLogger().setLevel(logging.DEBUG)
```

### Performance Monitoring

The system includes built-in performance monitoring:
- Check `jah_agency.log` for system events
- Monitor system status via `get_system_status()` method
- Database performance metrics in agent performance tables

## Next Steps

1. **Implement Specialized Agents**: Add full implementations for Marketing, Sales, Technical agents
2. **Financial Integration**: Connect to real banking APIs and payment processors
3. **Web Interface**: Create web dashboard for system monitoring and task management
4. **API Layer**: Implement RESTful API for external integrations
5. **Advanced Features**: Add ML-powered task analysis and agent optimization

## Getting Support

- Check logs in `jah_agency.log`
- Review database contents using SQL browser for SQLite
- Monitor system health via status endpoints
- Use debug mode for detailed troubleshooting

The system is designed to be modular and extensible. Start with the basic setup and gradually add more sophisticated features as needed.